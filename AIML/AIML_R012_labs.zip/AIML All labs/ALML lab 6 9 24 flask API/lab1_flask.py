from flask import Flask, request

app = Flask(__name__)

@app.route("/")
def hello_world():
    return "<p>Hello, World!</p>"

# EndPoint with @ decorator
@app.route("/first")
def hello_world2():
    return "<p>/first path</p>"


if __name__== "__main__":
    # With app.run, you can directly run this as a python script
    app.run(debug=True)

# Running the app
# RUNNING THE APP: python -m flask --app flask/lab1_quickstart.py run
# RUNNING APP OVER WEB: python -m flask --app flask/lab1_quickstart.py run --host=0.0.0.0
# GETTING DATA FROM JSON: curl http://127.0.0.1:5000/getname -H "Content-Type:application/json" -d '{"Name": "ajinkya"}'


#ajinky kole github::::: https://github.com/ajinkyakolhe112/Workshop-NMIMS-MTech-2024/tree/main